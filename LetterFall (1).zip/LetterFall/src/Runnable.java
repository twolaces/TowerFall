/**
 * Created by toomeyt0 on 4/8/2016.
 */
public interface Runnable {
    public boolean isRunning();
    public void run();
    public void stop();
}
